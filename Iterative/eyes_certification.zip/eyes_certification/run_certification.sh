#!/usr/bin/env bash
# run_certification.sh -- FR196 closure at the FR162 standard, both systems.
#
# Put this file in ONE directory together with:
#   eyemax_v2.c                     (from FR196 outputs -- NOT the old eyemax.c;
#                                    the mandatory file needs v2's 1024-seed capacity)
#   maxset_problem_mandatory.txt    (FR196 outputs)
#   maxset_orders_mandatory.txt     (FR196 outputs)
#   reduce_validated.py             (FR196 outputs)
#   maxset_problem.txt              (the archive's classes-only pair, unchanged)
#   maxset_orders.txt
#
# Usage:   bash run_certification.sh [runs] [threads]
#          bash run_certification.sh 795545 32
#
# No chmod needed -- invoke via bash as above. Expected wall time at 32
# threads: roughly 10-15 minutes per system.
set -euo pipefail
RUNS="${1:-795545}"; THREADS="${2:-32}"
cd "$(dirname "$0")"
command -v gcc >/dev/null || { echo "XD-MBYG04K-URS3LF: need gcc (apt install build-essential)"; exit 2; }
for f in eyemax_v2.c maxset_problem_mandatory.txt maxset_orders_mandatory.txt \
         reduce_validated.py maxset_problem.txt maxset_orders.txt; do
  [ -f "$f" ] || { echo "XD-MBYG04K-URS3LF: missing $f"; exit 2; }
done

echo "== build (native flags are fine on your own host) =="
gcc -O3 -march=native -fopenmp -o eyemax eyemax_v2.c

# The binary opens "maxset_orders.txt" from its own cwd, and the two systems
# need DIFFERENT orders files with that same name -> one directory per system.
mkdir -p mand ctrl
cp eyemax mand/; cp eyemax ctrl/
cp maxset_problem_mandatory.txt mand/maxset_problem.txt
cp maxset_orders_mandatory.txt  mand/maxset_orders.txt
cp maxset_problem.txt ctrl/
cp maxset_orders.txt  ctrl/

echo "== mandatory system: $RUNS orders on $THREADS threads =="
echo "   (gate must print 794/61/8 PASS x3 + canary PASS before running)"
( cd mand && ./eyemax maxset_problem.txt "$RUNS" "$THREADS" > m_all.txt )

echo "== control system: $RUNS orders on $THREADS threads =="
echo "   (gate must print 794/61/6, 724/61/6, 794/61/6 PASS + canary PASS)"
( cd ctrl && ./eyemax maxset_problem.txt "$RUNS" "$THREADS" > ctrl_all.txt )

cp ctrl/ctrl_all.txt .    # reduce_validated.py's expected paths
echo "== validated reduction =="
python3 reduce_validated.py
echo
echo "Expected: MANDATORY distinct 1, Chao1 1.0, corrupt 0."
echo "          CONTROL   distinct 68, Chao1 ~68 (FR162's exhaustive answer)."
echo "Anything else is a finding -- send the two output blocks."
