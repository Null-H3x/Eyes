FR196 CERTIFICATION BUNDLE -- self-contained, nothing else needed.

  unzip eyes_certification.zip
  cd eyes_certification
  bash run_certification.sh 795545 32

Gates print first (mandatory: 794/61/8 PASS x3; control: 794/61/6,
724/61/6, 794/61/6 PASS; canary PASS each). ~10-15 min per system at
32 threads. Expected finals: MANDATORY distinct 1, Chao1 1.0, corrupt 0;
CONTROL distinct 68, Chao1 ~68. Anything else: send both output blocks.

Contents: run_certification.sh, eyemax_v2.c (REQUIRED build -- the old
eyemax.c stack-smashes on the 539-seed mandatory file), the mandatory
problem/orders pair (FR196), the archive's classes-only pair (control),
reduce_validated.py, this file.
